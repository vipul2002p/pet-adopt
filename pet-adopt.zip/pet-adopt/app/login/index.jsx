import { StyleSheet, Text, View,Image,Button, Pressable} from "react-native";
import {useFonts} from "expo-font";
import { Link } from 'expo-router'
import { useOAuth } from '@clerk/clerk-expo'
import * as Linking from 'expo-linking'
import * as WebBrowser from 'expo-web-browser'
import { useEffect,useCallback } from "react";
export const useWarmUpBrowser = () => {
    useEffect(() => {
      // Warm up the android browser to improve UX
      // https://docs.expo.dev/guides/authentication/#improving-user-experience
      void WebBrowser.warmUpAsync()
      return () => {
        void WebBrowser.coolDownAsync()
      }
    }, [])
  }
  
  WebBrowser.maybeCompleteAuthSession()

export default function Page() {
    useWarmUpBrowser()

  const { startOAuthFlow } = useOAuth({ strategy: 'oauth_google' })

  const onPress = useCallback(async () => {
    try {
      const { createdSessionId, signIn, signUp, setActive } = await startOAuthFlow({
        redirectUrl: Linking.createURL('/home', { scheme: 'myapp' }),
      })

      if (createdSessionId) {
        
      } else {
        // Use signIn or signUp for next steps such as MFA
      }
    } catch (err) {
      console.error('OAuth error', err)
    }
  }, [])

  return (
    <View style={styles.container}>
      <Image style={styles.image} source={require('./../../assets/images/Main.png')}/>
      <View style={styles.innerView}>
        <Text style={styles.heading}>Ready To Make A New Friend?</Text>
        <Text style={styles.title}>Let's adopt the pet which you like and make their life happy again</Text>
        <Pressable style={styles.btn} onPress={onPress}>
          <Text style={styles.btnText}>Get Started</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
container : {
  width : "100%",
},
text : {
  fontFamily : 'robotoBold',
},
image  :{
  width : "100%",
  height : 450,
},
innerView : {
padding : 35,
},
heading : {
  fontSize : 28,
  fontFamily : "robotoMedium",
  textAlign : "center",
  color : "#1E201E",
  letterSpacing : 1
},
title : {
  marginTop : 5,
  marginBottom : 18,
  fontSize : 17,
  textAlign : "center",
  fontFamily : "roboto",
  color : "#686D76"
},
btn : {
  padding : 10,
  backgroundColor : "#FCDE70",
  borderWidth : 1,
  borderColor : "#222",
  borderRadius : 6,
},
btnText : {
  textAlign : "center",
  fontFamily : "robotoBold",
  fontSize : 18,
}
});
