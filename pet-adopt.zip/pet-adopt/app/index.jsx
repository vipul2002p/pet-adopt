import { StyleSheet, Text, View, Image, Button, Pressable } from "react-native";
import { useFonts } from "expo-font";
import { Link } from "expo-router";

export default function Page() {


  return (
    <View style={styles.container}>
      <Link href={'login/'} >
        <Text>Co TO Home</Text>
      </Link>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: "100%",
  }
});
